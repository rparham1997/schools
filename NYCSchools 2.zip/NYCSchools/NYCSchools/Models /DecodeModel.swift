//
//  DecodeModel.swift
//  NYCSchools
//
//  Created by Ramar Parham on 12/26/19.
//  Copyright © 2019 Ramar Parham. All rights reserved.
//

//import Foundation

//class DecodeModel {
    
    //func decode(from data: Data?) {
//        if let json = JSONSerialization.jsonObject(with: data ?? <#default value#>, options:)
    //}
    
    //if; let json = try?
//}
